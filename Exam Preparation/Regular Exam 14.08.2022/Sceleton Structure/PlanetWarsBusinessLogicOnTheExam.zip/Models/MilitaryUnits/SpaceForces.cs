﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class SpaceForces : MilitaryUnit
    {
        private const double CostValue = 11;
        public SpaceForces()
            : base(CostValue)
        {
        }
    }
}
