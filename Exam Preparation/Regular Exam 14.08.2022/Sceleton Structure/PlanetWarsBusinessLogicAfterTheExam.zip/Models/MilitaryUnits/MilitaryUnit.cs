﻿namespace PlanetWars.Models.MilitaryUnits
{
    using System;
    using System.Text;
    using System.Collections.Generic;

    using Contracts;
    using Utilities.Messages;

    public abstract class MilitaryUnit : IMilitaryUnit
    {
        private int EnduranceLevelValue = 1;
        public MilitaryUnit(double cost)
        {
            this.Cost = cost;
        }

        public double Cost { get; private set; }

        public int EnduranceLevel => EnduranceLevelValue;

        public void IncreaseEndurance()
        {
            EnduranceLevelValue++;

            if (this.EnduranceLevel > 20)
            {
                EnduranceLevelValue = 20;

                throw new ArgumentException(string.Format(ExceptionMessages.EnduranceLevelExceeded));
            }
        }
    }
}
