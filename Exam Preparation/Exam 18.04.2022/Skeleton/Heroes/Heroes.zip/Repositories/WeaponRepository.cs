﻿using Heroes.Models.Contracts;
using Heroes.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes.Repositories
{
    public class WeaponRepository : IRepository<IWeapon>
    {
        private readonly HashSet<IWeapon> models;

        public WeaponRepository()
        {
            this.models = new HashSet<IWeapon>();
        }

        public IReadOnlyCollection<IWeapon> Models => this.models;

        public void Add(IWeapon model)
        {
                this.models.Add(model);
        }

        public bool Remove(IWeapon model)
        {
            return this.models.Remove(model);
        }

        public IWeapon FindByName(string name)
        {
            IWeapon foundWeapon = this.models.FirstOrDefault(w => w.Name == name);

            return foundWeapon;
        }
    }
}
