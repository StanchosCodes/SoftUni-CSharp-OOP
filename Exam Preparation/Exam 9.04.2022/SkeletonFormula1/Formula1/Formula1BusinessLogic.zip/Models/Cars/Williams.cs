﻿namespace Formula1.Models.Cars
{
    public class Williams : FormulaOneCar
    {
        public Williams(string model, int horsePower, double engineDispacement)
            : base(model, horsePower, engineDispacement)
        {
        }
    }
}
