﻿namespace Formula1.Models.Cars
{
    public class Ferrari : FormulaOneCar
    {
        public Ferrari(string model, int horsePower, double engineDispacement)
            : base(model, horsePower, engineDispacement)
        {
        }
    }
}
