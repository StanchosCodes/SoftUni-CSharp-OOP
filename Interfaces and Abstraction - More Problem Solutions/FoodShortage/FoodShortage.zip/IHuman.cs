﻿namespace FoodShortage
{
    public interface IHuman
    {
        string Name { get; }
        int Age { get; }
    }
}
