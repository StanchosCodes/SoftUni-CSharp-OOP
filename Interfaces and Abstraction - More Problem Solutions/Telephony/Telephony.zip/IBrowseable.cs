﻿namespace Telephony
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
