﻿namespace BorderControl
{
    public interface IIdentifiable
    {
        string Name { get; }
        string Id { get; }
    }
}
