﻿namespace WildFarm
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {

        }
    }
}
